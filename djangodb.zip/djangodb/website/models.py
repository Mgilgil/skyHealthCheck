# Authored by Mehmet Gilgil w2046446

from django.db import models
from django.contrib.auth.models import User

# Represents a department within the organization
class Department(models.Model):
    deptID = models.CharField(max_length=10, primary_key=True)
    dname = models.CharField(max_length=100)
    dloc = models.CharField(max_length=100)
    
    def __str__(self):
        return f"{self.dname} Located at {self.dloc}"

# Represents a team, linked to a department
class Team(models.Model):
    teamID = models.CharField(max_length=10, primary_key=True)
    tname = models.CharField(max_length=50)
    deptID = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True)  # Allow teams without a department if deleted

    def __str__(self):
        return f"{self.tname} at {self.deptID.dname}"


class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('engineer', 'Engineer'),
        ('team_leader', 'Team Leader'),
        ('department_leader', 'Department Leader'),
        ('senior_manager', 'Senior Manager'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)  # One user gets one profile
    deptID = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True)
    teamID = models.ForeignKey(Team, on_delete=models.SET_NULL, null=True)
    role = models.CharField(max_length=30, choices=ROLE_CHOICES, default='engineer')  

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name}"


# Represents a work or meeting session linked to a user
class Session(models.Model):
    sessionID = models.CharField(max_length=10, primary_key=True)
    sdate = models.DateTimeField()  # Date and time when session happened
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)  # Who attended the session

    def __str__(self):
        return self.sessionID

# Represents a card that users interact with (probably voting or feedback?)
class Card(models.Model):
    cardID = models.CharField(max_length=10, primary_key=True)
    cname = models.CharField(max_length=100)
    cdesc = models.CharField(max_length=500)  # Good/positive description
    cdescbad = models.CharField(max_length=500, null=True)  # Optional negative description

    def __str__(self):
        return 'Card ID: ' + self.cardID + ' Name: ' + self.cname

# Stores votes associated with cards during sessions
class Vote(models.Model):
    voteID = models.CharField(max_length=10, primary_key=True)
    vstate = models.CharField(max_length=20)  # State of the vote (e.g., upvote/downvote?)
    vtrend = models.CharField(max_length=20)  # Trend or direction (e.g., positive/negative)
    vcomments = models.CharField(max_length=500)  # Comments left with the vote
    cardID = models.ForeignKey(Card, on_delete=models.SET_NULL, null=True)  # Vote is tied to a card
    sessionID = models.ForeignKey(Session, on_delete=models.SET_NULL, null=True)  # Vote is tied to a session
