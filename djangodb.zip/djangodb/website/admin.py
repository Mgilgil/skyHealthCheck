# Authored by Mehmet Gilgil w2046446

from django.contrib import admin
from django.contrib.auth.models import User
from .models import Department, Team, UserProfile, Session, Card, Vote

# Register custom models to make them manageable through the Django admin panel
admin.site.register(Department)  # Manage departments
admin.site.register(Team)        # Manage teams
admin.site.register(UserProfile) # Manage extended user profiles
admin.site.register(Session)     # Manage sessions
admin.site.register(Card)        # Manage cards
admin.site.register(Vote)        # Manage votes
