# Authored by Entire group

# Import necessary Django modules for URL routing and views
from django.urls import path
from . import views  # Import your custom views from the current directory
from django.contrib.auth import views as auth_views  # Import Django's built-in auth views for authentication

# Define URL patterns for the application
urlpatterns = [
     # Routes for user authentication (sign in, sign out, sign up) and the main application pages
    path('', views.home, name='home'),  # Landing page
    path('signin/', views.signin, name='signin'),  # Sign-in page
    path('signout/', views.signout, name='signout'),  # when the user signs out redirect to page
    path('signup/', views.signup, name='signup'),  # Sign-up page
    path('mainpage/', views.mainpage, name='mainpage'),  # Main application page
    path('healthcheck/', views.healthcheck, name='healthcheck'),  # Health check page
    path('summary/', views.summary, name='summary'),  # Summary page
    path('userprofile/', views.userprofile, name='userprofile'),  # User profile page
    path('update_password/', views.update_password, name='update_password'),
    path("thank_you/", views.thank_you, name="thank_you"),

    # Route for resetting the user's password (Django's built-in PasswordResetView)
    path('reset_password/', auth_views.PasswordResetView.as_view(template_name="password_reset.html"), name="reset_password"),

    # Route for notifying the user that the password reset email has been sent (Django's built-in PasswordResetDoneView)
    path('reset_password_sent/', auth_views.PasswordResetDoneView.as_view(template_name="password_reset_sent.html"), name="password_reset_done"),

    # Route for confirming the password reset with a token and uid (Django's built-in PasswordResetConfirmView)
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name="password_reset_form.html"), name="password_reset_confirm"),

    # Route for displaying the success message after the password reset is complete (Django's built-in PasswordResetCompleteView)
    path('reset_password_complete/', auth_views.PasswordResetCompleteView.as_view(template_name="password_reset_done.html"), name="password_reset_complete"),
]
