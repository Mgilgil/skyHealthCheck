# Authored by Entire group

from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .forms import SignUpForm, UpdateProfileForm, ChangePasswordForm
from .models import *
from django import forms

# Render the homepage
def home(request):
    return render(request, 'home.html')

# Handle user login
def signin(request):
    if request.method == "POST":
        # Get credentials from form
        username = request.POST['employeeID']
        password = request.POST['password']
        # Authenticate user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('mainpage')  # Redirect to main page after login
        else:
            messages.error(request, ('Incorrect details, try again!'))
            return redirect('signin')  # Reload login page on failure
    else:
        return render(request, 'signin.html')

# Handle user signup
def signup(request):
    form = SignUpForm()
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()  # Save the new user
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            messages.success(request, 'User created successfully!')
            return redirect('signin')  # Redirect to login after signup
        else:
            # Show validation errors if the form is invalid
            messages.error(request, 'Whoops! There was a problem with your submission. Please try again.')

    # Render signup page with the form
    return render(request, 'signup.html', {'form': form})

# Handle user logout
def signout(request):
    logout(request)
    messages.success(request, ('You have logged out.'))
    return redirect('home') 

# Render main page (requires login)
@login_required
def mainpage(request):
    return render(request, 'mainpage.html')

# Render health check page (requires login)
@login_required
def healthcheck(request):
    teams = [
        {"id": 1, "name": "Backend Team"},
        {"id": 2, "name": "Frontend Team"},
        {"id": 3, "name": "DevOps Team"},
        {"id": 4, "name": "QA Team"},
    ]


    teams = sorted(teams, key=lambda team: team["name"])

    if request.method == 'POST':
        selected_team = request.POST.get('team')
        selected_vote = request.POST.get('vote')


        return redirect('thank_you')

    return render(request, 'healthcheck.html', {'teams': teams})

@login_required
def thank_you(request):
    return render(request, 'thank_you.html')

# Render summary page (requires login)
@login_required
def summary(request):
    #Get the current user
    current_user = request.user
    this_user = UserProfile.objects.get(user_id=current_user)
    print(this_user)
    
    #User not assigned a department or team
    error = (this_user.role != "department_manager" and this_user.role != "senior_manager") and (not this_user.deptID_id or not this_user.teamID_id)
    print(error)
    
    departments = Department.objects.all()
    selected_dept = None
    if this_user.role == "senior_manager":
        teams = Team.objects.all()
    elif this_user.role == "department_leader":
        teams = Team.objects.filter(deptID_id=this_user.deptID_id)
    elif this_user.role == "team_leader":
        teams = Team.objects.filter(deptID_id=this_user.deptID_id)
    else:
        teams = None
    selected_team = None
    employees = None
    employee_id = None
    name = None
    votes = None
    cards = []#list of card ids in order with votes
    temp = []
    data = {"Green" : 0, "Amber" : 0, "Red" : 0,
            "Up" : 0, "Same" : 0, "Down" : 0}
    
    dept_id = request.GET.get("dept_id")
    if dept_id:
        try:
            selected_dept = Department.objects.get(deptID=dept_id)
            teams = Team.objects.filter(deptID_id=selected_dept)
        except Department.DoesNotExist:
            selected_dept = None
            
    team_id = request.GET.get("team_id")
    if team_id or this_user.role == "engineer":
        try:
            if this_user.role == "engineer":#Engineer only
                selected_team = Team.objects.get(teamID=this_user.teamID_id)
            else:
                selected_team = Team.objects.get(teamID=team_id)
            teams = Team.objects.filter(deptID_id=this_user.deptID_id)
            employees = UserProfile.objects.filter(teamID_id=selected_team)
        except Team.DoesNotExist:
            selected_team = None

    employee_id = request.GET.get("employee_id")
    flag = False
    if employee_id:
        try:
            #Getting the name
            name = UserProfile.objects.get(user_id=employee_id)
            name = User.objects.get(id=name.user_id)
            name = name.first_name + " " + name.last_name
            session = Session.objects.filter(user_id=employee_id)
            #Getting all votes from all sessions
            count = 0
            for s in session:
                votes = Vote.objects.filter(sessionID=session[count].sessionID)
                for v in votes:
                    temp.append(v)
                count += 1
            votes = temp
            flag = True
            
        except Exception as e:
            print("nope: " + str(e))
    elif selected_team or selected_dept:
        if selected_team:
            selected_team_members = UserProfile.objects.filter(teamID_id=selected_team)
        elif selected_dept:
            selected_team_members = UserProfile.objects.filter(deptID_id=selected_dept)
        for person in selected_team_members:
            session = Session.objects.filter(user_id=person.user_id)
            #Getting all votes from all sessions
            count = 0
            for s in session:
                votes = Vote.objects.filter(sessionID=session[count].sessionID)
                for v in votes:
                    temp.append(v)
                count += 1
        votes = temp
        flag = True
        
    if flag:
        for v in votes:
            card = Card.objects.get(cardID=v.cardID_id)
            card = card.cname
            cards.append(card)
                
            data[v.vstate] += 1
            data[v.vtrend] += 1
            
    
    return render(request, "summary.html", {
        "user_name" : this_user,
        "user_role" : this_user.role,
        "user_team" : this_user.teamID,
        "user_dept" : this_user.deptID,
        'departments': departments,
        'selected_dept': selected_dept,
        'teams': teams,
        'selected_team': selected_team,
        "employees": employees,
        "selected_employee": employee_id,
        "votes": votes,
        "name" : name,
        "data" : data,
        "cards" : cards,
        "error" : error
    })

# Render user profile page (requires login)
@login_required
def userprofile(request):

        current_user = User.objects.get(id=request.user.id)
        user_updateform = UpdateProfileForm(request.POST or None, instance=current_user)

        if user_updateform.is_valid():
            user_updateform.save()

            login(request, current_user)
            messages.success(request, "User profile has been updated")
            return redirect('home')
        return render(request, "userprofile.html", {'user_updateform':user_updateform})

def update_password(request):
    if request.user.is_authenticated:
        current_user = request.user
        if request.method == 'POST':
            form = ChangePasswordForm(current_user, request.POST)
            if form.is_valid():
                form.save()
                messages.success(request, "Password Has Been Updated, Please Sign In Again")
                return redirect('signin')
            else:
                for error in list(form.errors.values()):
                    messages.error(request, error)
                    return redirect('update_password')

        else:
            form = ChangePasswordForm(current_user)
            return render(request, "update_password.html", {'form':form})
    else:
        messages.success(request, "Log in to view")
        return  redirect('home')
    
