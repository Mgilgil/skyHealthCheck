# Authored by Hasan and Mehmet
# Import necessary Django modules for authentication
from typing import Any
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, SetPasswordForm
from django import forms
from .models import UserProfile  # Import your custom UserProfile model

# Define choices for the user's role, which will be presented in a dropdown menu
ROLE_CHOICES = [
    ('engineer', 'Engineer'),
    ('team_leader', 'Team Leader'),
    ('department_leader', 'Department Leader'),
    ('senior_manager', 'Senior Manager'),
]

# Define the SignUpForm, which inherits from Django's built-in UserCreationForm
class SignUpForm(UserCreationForm):
    # Define the email field with custom styling and a placeholder
    email = forms.EmailField(
        label="",  # Empty label (label is hidden)
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email Address'})  # Add classes and placeholder
    )

    # Define the first name field with custom styling and a placeholder
    first_name = forms.CharField(
        label="",  # Empty label (label is hidden)
        max_length=100,  # Set the maximum length for the first name
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'})  # Add classes and placeholder
    )

    # Define the last name field with custom styling and a placeholder
    last_name = forms.CharField(
        label="",  # Empty label (label is hidden)
        max_length=100,  # Set the maximum length for the last name
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'})  # Add classes and placeholder
    )

    # Define the role field with choices (dropdown menu)
    role = forms.ChoiceField(
        choices=ROLE_CHOICES,  # Use the predefined ROLE_CHOICES for dropdown options
        label="",  # Empty label (label is hidden)
        widget=forms.Select(attrs={'class': 'form-control'})  # Add classes for styling
    )

    # The Meta class defines the model and fields that should be used for this form
    class Meta:
        model = User  # Use the built-in User model
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'role')  # Include these fields in the form

    # Initialize the form and apply custom styles and placeholder text
    def __init__(self, *args, **kwargs):
        super(SignUpForm, self).__init__(*args, **kwargs)

        # Apply custom styles to the username field and set a helpful placeholder
        self.fields['username'].widget.attrs['class'] = 'form-control'
        self.fields['username'].widget.attrs['placeholder'] = 'Employee ID'  # Set the placeholder text
        self.fields['username'].label = ''  # Remove the label
        self.fields['username'].help_text = '<span class="form-text text-muted"><small>Please enter employee ID</small></span>'  # Add help text for the user

        # Apply custom styles to the password1 field (first password field) with a helpful password policy
        self.fields['password1'].widget.attrs['class'] = 'form-control'
        self.fields['password1'].widget.attrs['placeholder'] = 'Password'  # Set the placeholder text
        self.fields['password1'].label = ''  # Remove the label
        self.fields['password1'].help_text = (
            '<ul class="form-text text-muted small">'  # Help text in a bullet-point list
            '<li>Your password can\'t be too similar to your other personal information.</li>'
            '<li>Your password must contain at least 8 characters.</li>'
            '<li>Your password can\'t be a commonly used password.</li>'
            '<li>Your password can\'t be entirely numeric.</li>'
            '</ul>'
        )

        # Apply custom styles to the password2 field (confirm password field)
        self.fields['password2'].widget.attrs['class'] = 'form-control'
        self.fields['password2'].widget.attrs['placeholder'] = 'Confirm Password'  # Set the placeholder text
        self.fields['password2'].label = ''  # Remove the label

    # Overriding the save method to create a UserProfile instance along with the User instance
    def save(self, commit=True):
        # Save the user instance created by the UserCreationForm
        user = super().save(commit=commit)

        # Retrieve the role chosen by the user
        role = self.cleaned_data.get('role')

        # Create and save a UserProfile instance linked to the created user, storing the role
        UserProfile.objects.create(user=user, role=role)

        # Return the created user instance
        return user

class UpdateProfileForm(UserChangeForm):
    password = None
    first_name = forms.CharField(label='', max_length=30, widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'Enter First Name'}))
    last_name = forms.CharField(label='', max_length=30, widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'Enter Last Name'}))
    email = forms.EmailField(label="", widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'Enter Email Address'}))

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name','email')

    def __init__(self, *args: Any, **kwargs):
        super(UpdateProfileForm, self).__init__(*args, **kwargs)
        
        self.fields['username'].disabled = True
        self.fields['username'].widget.attrs['class'] = 'form-control'
        self.fields['username'].widget.attrs['placeholder'] = ''
        self.fields['username'].label = 'You cannot update your employee ID yourself. Please contact the django admin.'
        self.fields['username'].help_text = '<span class="form-text text-muted"><small></span>'

        
class ChangePasswordForm(SetPasswordForm):
    class Meta:
        model = User
        fields = ['new_password1', 'new_password2']

    def __init__(self, *args: Any, **kwargs):
        super(ChangePasswordForm, self).__init__(*args, **kwargs)
        
        self.fields['new_password1'].widget.attrs['class'] = 'form-control'
        self.fields['new_password1'].widget.attrs['placeholder'] = 'Password'
        self.fields['new_password1'].label = ''
        self.fields['new_password1'].help_text = '<span class="form-text text-muted"><small></span>'

        self.fields['new_password2'].widget.attrs['class'] = 'form-control'
        self.fields['new_password2'].widget.attrs['placeholder'] = 'Confirm Password'
        self.fields['new_password2'].label = ''
        self.fields['new_password2'].help_text = '<span class="form-text text-muted"><small></span>'
