# Authored by Mehmet Gilgil w2046446

from django.apps import AppConfig


class WebsiteConfig(AppConfig):
    
    default_auto_field = 'django.db.models.BigAutoField'
    
    # Name of the app this config refers to
    name = 'website'
